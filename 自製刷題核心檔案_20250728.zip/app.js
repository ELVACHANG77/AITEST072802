
let currentIndex = 0;
let questions = [];

fetch('quiz_data.json')
  .then(response => response.json())
  .then(data => {
    questions = data;
    loadNextQuestion();
  });

function loadNextQuestion() {
  const container = document.getElementById('quiz-container');
  if (currentIndex >= questions.length) {
    container.innerHTML = "<p>已完成所有題目！</p>";
    return;
  }
  const q = questions[currentIndex];
  let html = `<p><strong>Q${currentIndex + 1}：</strong>${q.question}</p>`;
  q.options.forEach((opt, idx) => {
    html += `<div><input type="radio" name="q${currentIndex}" /> ${opt}</div>`;
  });
  container.innerHTML = html;
  currentIndex++;
}
